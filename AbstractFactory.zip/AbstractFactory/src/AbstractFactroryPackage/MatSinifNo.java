package AbstractFactroryPackage;

public class MatSinifNo implements SinifNo {

   private static int SinifNo = 105;

    public int getSinifNo() {
        return SinifNo;
    }
}
