package AbstractFactroryPackage;

public interface SinifFactory {

   Ogrenciler createOgrenciler();

   Ogretmen createOgretmen();

    SinifNo createSinifNo();


}