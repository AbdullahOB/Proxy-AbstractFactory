package AbstractFactroryPackage;

public interface Ogrenciler {
    String getDescription();
}
