package AbstractFactroryPackage;

public interface SinifNo {
    
    int getSinifNo();

}