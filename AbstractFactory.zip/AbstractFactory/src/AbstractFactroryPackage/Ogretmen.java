package AbstractFactroryPackage;

public interface Ogretmen {
    String getDescription();
}